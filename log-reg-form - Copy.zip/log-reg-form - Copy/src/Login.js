import React, { useState } from 'react';
import './Login.css'
import Register from './Register';
import passwordlogo from './image/passwordlogo.jpg';
import phonelogo from './image/phonelogo.jpg';
import naicologoo from './image/nc.jpg';
import belllogo from './image/b.jpg';
import headphonelogo from './image/headphonelogo.jpg';

function Login(props){
  const [enteredPhone, setEnteredPhone] = useState('');
  const [enteredPassword, setEnteredPassword] = useState('');
  const [success, setSuccess] = useState(false);

  const phoneChangeHandler = (event) => {
    setEnteredPhone(event.target.value);
  };
  const passwordChangeHandler = (event) => {
    setEnteredPassword(event.target.value);
  };

  const submitHandler = (event) => {
    event.preventDefault();
    console.log({enteredPhone})
    // setAuth({ user, pwd, roles, accessToken });
    setEnteredPhone('');
    setEnteredPassword('');
    if(enteredPhone=="9188543185" && enteredPassword=="smi"){
      setSuccess(true);
    }
    
    const loginData = {
      phone: enteredPhone,
      password: enteredPassword,
    };

    // props.onSaveLoginData(loginData);
    // setEnteredPhone('');
    // setEnteredPassword('');
  };

  return (
    <>
        {success ? (
            <section>
              <Register></Register>
                {/* <h1>You are logged in!</h1>
                <br />
                <p>
                    <a href="#">Go to Home</a>
                </p> */}
            </section>
        ) : (
            <section>
              <div>
          <div className='navbar'>
            <div>
            <img src={naicologoo} alt="naico" className='naicologo'/>
            </div>
            <div>
              <div>
              <img src={belllogo} alt="bell" className='belllogo'/>
              <label className='lbl'>|</label>
            <img src={headphonelogo} alt="headphone" className='headphonelogo'/>
              </div>
            
            </div>
            
          </div>
          <form onSubmit={submitHandler}>
          <div className="main">
          <div className="sub-main">
            <div>
              <div >
              <h3 style={{color: "blue", textAlign: "center"}} >Sign In</h3>
              <p style={{textAlign: "center"}}>Enter Your Email/Mobile Number</p>
    
              
                  <div>
                    <img src={phonelogo} alt="phonenumber" className='phonelogo'/>
                    <input type="text" placeholder='Enter Your email/Mobile Number' className='name'
                    value={enteredPhone}
                    onChange={phoneChangeHandler}></input>
                  </div>
    
                  <div>
                    <img src={passwordlogo} alt="password" className='passwordlogo'/>
                    <input type="password" placeholder='Enter Password' className='name'
                    value={enteredPassword}
                    onChange={passwordChangeHandler}></input>
                  </div>
                  <div>
                    <div>
                    <input type="checkbox" value="lsRememberMe" id="rememberMe" className='chkbox'></input> <label for="rememberMe">Remember me</label>
                    &nbsp;  &nbsp;  &nbsp;  &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; 
                    <a href='#' style={{alignTracks:"end"}}>Forget Password?</a>
                  </div>
                  </div>
                  <button className='btn'>SIGN IN</button>
                </div>
                <div>
                  <div style={{textAlign:"center", marginBottom:"30px"}} >
                  <a href='#'>Sign In </a><label>with Mobile & OTP</label>
                  </div>
                </div>
                <div>
                  <div style={{textAlign:"center", marginTop:"90px"}}>
                    <label>Having trouble?</label><a href='#'> Get Help</a>
                  </div>
                </div>
            </div>
          </div>
          
        </div>
          </form>
        
        </div>
            </section>
        )}
    </>
);


}

export default Login;