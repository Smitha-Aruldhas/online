import mysql.connector

mydb=mysql.connector.connect(
    host="localhost",
    user="root",
    password="password123"
)

mycusor = mydb.cursor()

mycusor.execute("CREATE DATABASE logindb")