from django.shortcuts import render
from rest_framework.views import APIView
from . models import *
from . serializer import *
from rest_framework.response import Response


class ReactView(APIView):
    
    serializer_class = ReactSerializer
    
    def get(self, request):
        output = [{"email":output.email,
                   "phone":output.phone,
                   "password":output.password}
                  for output in React.objects.all()]
        return Response(output)
    
    def post(self,request):
        
        serializer = ReactSerializer(data=request.data)
        if serializer.is_valid(raise_exception=True):
            serializer.save()
            return Response(serializer.data)
