from django.db import models

# Create your models here.
class React(models.Model):
    email = models.CharField(max_length=25)
    phone = models.IntegerField()
    password = models.CharField(max_length=15)