
// import './App.css';
import axios from 'axios';
import React from 'react';

class App extends React.Component {
  state ={ details: [], }

  componentDidMount(){

    let data;
    axios.get('http://localhost:8000')
    .then(res => {
      data = res.data;
      this.setState({
        details: data
      });
    })
    .catch(err => {})
  }

  render(){
    return(
      <div>
        <header> Data from backend</header>
        {this.state.details.map((output, id) => (
        <div key={id}>
          <div>
          <h1>{output.email}</h1>
          <h1>{output.phone}</h1>
          <h1>{output.password}</h1>
          </div>
        </div>
      ))}
      </div>
    )
  }
}

export default App;


// import axios from 'axios';
// import React, { useState, useEffect } from 'react';

// function App() {
//   const [data, setData] = useState([]);

//   useEffect(() => {
//     axios.get('http://localhost:8000/')
//       .then(response => {
//         setData(response.data);
//       })
//       .catch(error => {
//         console.log(error);
//       });
//   }, []);

//   return (
//     <div>
//       <h1>Data from Django API:</h1>
//       <ul>
//         {data.map(item => (
//           <li key={item.id}>{item.email} - {item.phone}</li>
//         ))}
//       </ul>
//     </div>
//   );
// }

// export default App;



// import "./App.css";
// import axios from "axios";
// import Login from "./Login";
// import { useEffect, useState } from "react";

// const API_URL = "http://localhost:8000";

// async function  getAPIData() {
//   return axios.get(API_URL).then((response) => response.data);
// }

// function App() {
//   const [login, setLogin] = useState([]);
//   // const [phone, setPhone] = useState([]);
//   // const [password, setPassword] = useState([]);

//   useEffect(() => {
//     let mounted = true;
//     getAPIData().then((items) => {
//       if (mounted) {
//         setLogin(items);
//       }
//     });
//     return () => (mounted = false);
//   }, []);

//   return (
//     <div className="App">
//       <h1>Hello</h1>
//       <Login login={login} />
//     </div>
//   );
// }

// export default App;
