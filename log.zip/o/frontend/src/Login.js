import React from "react";

function Login(props) {
  return (
    <div>
      <h1>These details are from the API</h1>
      {props.login.map((log) => {
        return (
          <div key={log.id}>
            <h2>{log.email}</h2>
            <p>{log.phone}</p>
            <p>{log.password}</p>
          </div>
        );
      })}
    </div>
  );
}

export default Login;