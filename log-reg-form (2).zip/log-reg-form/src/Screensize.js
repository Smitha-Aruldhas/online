import React, { useState } from 'react'
import { useEffect } from 'react'

const Screensize = () => {
    const [windowDimension, detectHW] = useState({
        winWidth: window.innerWidth,
        winHeight: window.innerWidth,
    })

    const detectSize = () => {
        detectHW({
            winWidth: window.innerWidth,
            winHeight: window.innerWidth,
        })
    }
        useEffect(() =>{
            window.addEventListener('resize', detectSize)

            return() => {
                window.removeEventListener('resize', detectSize)
            }
        }, [windowDimension])
    
  return (
    <div>
      
    </div>
  )
}

export default Screensize;
