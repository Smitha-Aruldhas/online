import React, { useState } from 'react';
import './Register.css'
import passwordlogo from './image/passwordlogo.jpg';
import phonelogo from './image/phonelogo.jpg';
import naicologoo from './image/nc.jpg';
import belllogo from './image/b.jpg';
import headphonelogo from './image/headphonelogo.jpg';

function Register(){
  const [enteredOtp1, setEnteredOtp1] = useState('');
  const [enteredOtp2, setEnteredOtp2] = useState('');
  const [enteredOtp3, setEnteredOtp3] = useState('');
  const [enteredOtp4, setEnteredOtp4] = useState('');
  const [enteredOtp5, setEnteredOtp5] = useState('');
  const [enteredOtp6, setEnteredOtp6] = useState('');
  const [success, setSuccess] = useState(false);
  const otpChangeHandler1 = (event) => {
    setEnteredOtp1(event.target.value);
  };
  const otpChangeHandler2 = (event) => {
    setEnteredOtp2(event.target.value);
  };
  const otpChangeHandler3 = (event) => {
    setEnteredOtp3(event.target.value);
  };
  const otpChangeHandler4 = (event) => {
    setEnteredOtp4(event.target.value);
  };
  const otpChangeHandler5 = (event) => {
    setEnteredOtp5(event.target.value);
  };
  const otpChangeHandler6 = (event) => {
    setEnteredOtp6(event.target.value);
  };

  const submitHandler = (event) => {
    event.preventDefault();
    console.log({enteredOtp1})
    // setAuth({ user, pwd, roles, accessToken });
    setEnteredOtp1('');
    setEnteredOtp2('');
    setEnteredOtp3('');
    setEnteredOtp4('');
    setEnteredOtp5('');
    setEnteredOtp6('');
    setSuccess(true);

    
    // const loginData = {
    //   name: enteredName,
    //   phone: enteredPhone,
    //   password: enteredPassword,
    // };

    // props.onSaveLoginData(loginData);
    // setEnteredPhone('');
    // setEnteredPassword('');
  };

  return (
    <>
        {success ? (
            <section>
                <h1>You are Succesfully Registered!</h1>
                <br />
                <p>
                    <a href="#">Go to Home</a>
                </p>
            </section>
        ) : (
            <section>
              <div>
          <div className='navbar'>
            <div>
            <img src={naicologoo} alt="naico" className='naicologo'/>
            </div>
            <div>
              <div>
              <img src={belllogo} alt="bell" className='belllogo'/>
              <label className='lbl'>|</label>
            <img src={headphonelogo} alt="headphone" className='headphonelogo'/>
              </div>
            
            </div>
            
          </div>
          <form onSubmit={submitHandler}>
          <div className="Reg">
          <div className="sub-Reg">
            <div>
              <div >
              <h4 style={{color: "blue", textAlign: "center"}} >Enter OTP</h4>
              <p style={{textAlign: "center"}}>OTP has sent to your Mobile Number</p>
    
                <div>
                    <input type="text"  className='otp'
                    value={enteredOtp1}
                    onChange={otpChangeHandler1}></input>
                
                    <input type="text"  className='otp'
                    value={enteredOtp2}
                    onChange={otpChangeHandler2}></input>
                
                    <input type="text"  className='otp'
                    value={enteredOtp3}
                    onChange={otpChangeHandler3}></input>
                
                    <input type="text"  className='otp'
                    value={enteredOtp4}
                    onChange={otpChangeHandler4}></input>
                
                    <input type="text"  className='otp'
                    value={enteredOtp5}
                    onChange={otpChangeHandler5}></input>
                
                    <input type="text"  className='otp'
                    value={enteredOtp6}
                    onChange={otpChangeHandler6}></input>
                </div>
                  <div>
                    <div>
                    <input type="checkbox" value="lsRememberMe" id="rememberMe" className='chkbox'></input> <label for="rememberMe">Remember me</label>
                    &nbsp;  &nbsp;  &nbsp;  &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; 
                    <a href='#' style={{alignTracks:"end"}}>Forget Password?</a>
                  </div>
                  </div>
                  <button className='btn'>SIGN IN</button>
                </div>
                <div>
                  <div style={{textAlign:"center", marginBottom:"30px"}} >
                  <a href='#'>Sign In </a><label>with Mobile & OTP</label>
                  </div>
                </div>
                <div>
                  <div style={{textAlign:"center", marginTop:"90px"}}>
                    <label>Having trouble?</label><a href='#'> Get Help</a>
                  </div>
                </div>
            </div>
          </div>
          
        </div>
          </form>
        
        </div>
            </section>
        )}
    </>
);


}

export default Register;