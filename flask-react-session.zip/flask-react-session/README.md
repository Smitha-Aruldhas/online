# Flask React Session Authentication

Video: https://www.youtube.com/watch?v=sBw0O5YTT4Q
