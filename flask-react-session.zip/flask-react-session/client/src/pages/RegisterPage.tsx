import React,{useState} from 'react'
import httpClient from '../httpClient'
import './LoginPage.css'
import passwordlogo from './image/passwordlogo.jpg';
import phonelogo from './image/phonelogo.jpg';
import naicologoo from './image/nc.jpg';
import belllogo from './image/b.jpg';
import headphonelogo from './image/headphonelogo.jpg';
const RegisterPage: React.FC = () => {
    const [email, setEmail] = useState<string>("")
    const [password, setPassword] = useState<string>("")
    const registerUser = async () => {
        console.log(email, password);

        try{
            const resp = await httpClient.post("//localhost:5000/register",{
            email,
            password,
        });
        window.location.href ="/";
        }

       catch (error: any) {
        if (error.response.status === 401 ){
            alert("Invalid credentials")
        }
       }
    };
  
  
  return (
    <div >
        <div className = 'navbar'>
            <div>
                <img src={naicologoo} alt="naico" className='naicologo'/>
            </div>
            <div>
                <div>
                    <img src={belllogo} alt="bell" className='belllogo'/>
                    <label className='lbl'>|</label>
                    <img src={headphonelogo} alt="headphone" className='headphonelogo'/>
                </div>
            </div>
        </div>
        <div>
            
            <form>
             <div className='main'>
                <div className='sub-main'>
                <div className='txt-sign'>
                <h3>Register</h3>
                </div>
                <div className='txt-enter'>
                <p>Create Your Account</p>
                </div>
                <div>
                <div>
                <img src={phonelogo} alt="phonenumber" className='phonelogo'/>
                    <input className='inp' type="text" value={email} onChange={(e) => setEmail(e.target.value)} id="" placeholder='Enter Your Email id' />
                </div>
                <div>
                <img src={passwordlogo} alt="password" className='passwordlogo'/>
                    <input className='inp' type="password" value={password} onChange={(e) => setPassword(e.target.value)} id="" placeholder='Enter Your Password'/>
                </div>
                </div>
                

                    <div>
                        <div>
                          <input type="checkbox" value="lsRememberMe" id="rememberMe" className='chkkbox'></input> <label>Remember me</label>
                          &nbsp;  &nbsp;  &nbsp;  &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; 
                          <a href='#' style={{alignTracks:"end"}}>Forget Password?</a>
                        </div>
                    </div>
                
                    <button type='button' className='buton' onClick={() => registerUser ()}>REGISTER</button>
                
                

                <div>
                    <div style={{textAlign:"center", marginBottom:"30px"}} >
                      <a href='#'>Sign In </a><label>with Mobile & OTP</label>
                    </div>
                    <div>
                      <div style={{textAlign:"center"}}>
                        <label>Having trouble?</label><a href='#'> Get Help</a>
                      </div>
                    </div>
                </div>
              </div> 
              </div> 
             </form>
            </div>
        </div>
    
  )
}

export default RegisterPage;