import React from 'react'

const HomePage = () => {
  return (
    <div className='navbar'>
        <div className='main'>

        </div>
    </div>
  )
}

export default HomePage