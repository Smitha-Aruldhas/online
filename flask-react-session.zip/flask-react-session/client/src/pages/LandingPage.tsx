import React, {useState, useEffect} from 'react'
// import '../index.css'
import { User } from '../types'
import httpClient from '../httpClient';
import naicologoo from './image/nc.jpg';
import belllogo from './image/b.jpg';
import verticallogo from './image/verticallogo.jpg';
import headphonelogo from './image/headphonelogo.jpg';

const LandingPage: React.FC = () => {
  const [user, setUser] = useState<User | null>(null);

  const logoutUser = async () => {
    await httpClient.post("//localhost:5000/logout")
    window.location.href="/";
  }

  useEffect(() =>{
    (async () => {
      try{
        const resp = await httpClient.get("//localhost:5000/@me")
      setUser(resp.data);
      }
      catch(error){
        console.log("Not authenticated")
      }
    })();
  }, []);
  return (
    <div>
      <div className='navbar'>
        <div>
                <img src={naicologoo} alt="naico" className='naicologo'/>
            </div>
            <div>
                <div>
                    <img src={belllogo} alt="bell" className='belllogo'/>
                    <img src={verticallogo} alt="line" className='verticallogo'/>
                    <img src={headphonelogo} alt="headphone" className='headphonelogo'/>
                </div>
            </div>
      </div>
      <div className='main'>
        <div>
        <h1>Welcome</h1>
      <div>
        {user != null ? (
          <div>
            <h1> Logged In</h1>
          <h2>Email : {user.email}</h2>
          
            <button onClick = {logoutUser} >Logout</button>
          
          </div>
        ) : (
          
          <div >
          <a href="/login">
            <button className='buton'>Login</button>
          </a>
          <a href='register'>
            <button className='buton'>Register</button>
          </a>
        </div>
        )}
      </div>
        </div>
      </div>
    </div>
  )
}

export default LandingPage;
