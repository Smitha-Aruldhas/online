import React, { useState } from 'react';
import styles  from './OtpPage.module.css';
import httpClient from '../httpClient'
import naicologoo from './image/nc.jpg';
import belllogo from './image/b.jpg';
import headphonelogo from './image/headphonelogo.jpg';

const OtpPage = () => {
    const [enteredOtp1, setEnteredOtp1] = useState('');
    const [enteredOtp2, setEnteredOtp2] = useState('');
    const [enteredOtp3, setEnteredOtp3] = useState('');
    const [enteredOtp4, setEnteredOtp4] = useState('');
    const [enteredOtp5, setEnteredOtp5] = useState('');
    const [enteredOtp6, setEnteredOtp6] = useState('');
    const [success, setSuccess] = useState(false);
    const logUser = async () => {
        window.location.href ="/";
    }
    return (
            <div>
            <div className={styles['navbar']}>
              <div>
              <img src={naicologoo} alt="naico" className={styles['naicologo']}/>
              </div>
              <div>
                <div>
                <img src={belllogo} alt="bell" className={styles['belllogo']}/>
                <label className={styles['lbl']}>|</label>
              <img src={headphonelogo} alt="headphone" className={styles['headphonelogo']}/>
                </div>
              
              </div>
              
            </div>
            <form>
            <div className={styles['Reg']}>
            <div className={styles['sub-Reg']}>
              <div>
                <div >
                <h4 style={{color: "blue", textAlign: "center"}} >Enter OTP</h4>
                <p style={{textAlign: "center"}}>OTP has sent to your Mobile Number</p>
      
                  <div>
                      <input type="text"  className={styles['otp']}
                      value={enteredOtp1}
                      onChange={(e) => setEnteredOtp1(e.target.value)}></input>
                  
                      <input type="text"  className={styles['otp']}
                      value={enteredOtp2}
                      onChange={(e) => setEnteredOtp2(e.target.value)}></input>
                  
                      <input type="text"  className={styles['otp']}
                      value={enteredOtp3}
                      onChange={(e) => setEnteredOtp3(e.target.value)}></input>
                  
                      <input type="text"  className={styles['otp']}
                      value={enteredOtp4}
                      onChange={(e) => setEnteredOtp4(e.target.value)}></input>
                  
                      <input type="text"  className={styles['otp']}
                      value={enteredOtp5}
                      onChange={(e) => setEnteredOtp5(e.target.value)}></input>
                  
                      <input type="text"  className={styles['otp']}
                      value={enteredOtp6}
                      onChange={(e) => setEnteredOtp6(e.target.value)}></input>
                  </div>
                    <div>
                      <div>
                      <input type="checkbox" value="lsRememberMe" id="rememberMe" className={styles['chkbox']}></input> <label>Remember me</label>
                      &nbsp;  &nbsp;  &nbsp;  &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; 
                      <a href='#' style={{alignTracks:"end"}}>Forget Password?</a>
                    </div>
                    </div>
                    <button className={styles['btn']} type='button' onClick={() => logUser ()}>SUBMIT</button>
                  </div>
                  <div>
                    <div style={{textAlign:"center", marginBottom:"30px"}} >
                    <a href='#'>Sign In </a><label>with Mobile & OTP</label>
                    </div>
                  </div>
                  <div>
                    <div style={{textAlign:"center", marginTop:"90px"}}>
                      <label>Having trouble?</label><a href='#'> Get Help</a>
                    </div>
                  </div>
              </div>
            </div>
            
          </div>
            </form>
          
          </div>
              

      
  );
  
    }

export default OtpPage