import React from 'react'

const Notfound: React.FC = () => {
  return (
    <div> 
        <h1>404 Not Found</h1>
    </div>
  )
}

export default Notfound;