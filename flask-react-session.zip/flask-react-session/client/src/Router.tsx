import React from 'react'
import LandingPage from './pages/LandingPage';
import { BrowserRouter, Switch, Route } from 'react-router-dom';
import Notfound from './pages/Notfound';
import LoginPage from './pages/LoginPage';
import RegisterPage from './pages/RegisterPage';
import OtpPage from './pages/OtpPage';
import HomePage from './pages/HomePage';

const Router = () => {
  return (
    <BrowserRouter>
        <Switch>
            <Route path ="/" exact component={LandingPage} />
            <Route path="/login" exact component={LoginPage} />
            <Route path="/register" exact component={RegisterPage} />
            <Route path="/otp" exact component={OtpPage} />
            <Route path="/home" exact component={HomePage} />
            
            <Route component={Notfound}/>
        </Switch>
    </BrowserRouter>
  )
}

export default Router;


