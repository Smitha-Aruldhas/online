class ApplicationController < ActionController::Base
    def home

    end
    def about

    end
end
